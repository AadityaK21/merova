Merova brand kit (merova.app/brand)

Colours
  Black       #090909  the main colour: backgrounds and text
  Ivory       #F1EFE9  text and the logo on black, light sections
  Gray        #8E8B85  secondary text on black
  Vermilion   #FF4B38  a rare signal only, never a background

Type
  Instrument Sans (headings and text) and IBM Plex Mono (small labels).
  Both are free on Google Fonts.

Logo
  Use the files as they are. Ivory logo on black, black logo on ivory or white.
  Don't stretch, rotate, recolour or redraw it, and don't add effects.

Questions: hello@merova.app
