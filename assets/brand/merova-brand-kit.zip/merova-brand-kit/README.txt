Merova brand kit (merova.app/brand)

Colours
  Ink    #0C0C0D  backgrounds and text
  Bone   #EEECE7  text and the logo on Ink
  Paper  #F2F0EB  light backgrounds
  Sage   #C1E1C1  Merova Fit only

Type
  Sora (headings and text) and IBM Plex Mono (labels). Both are free on Google Fonts.

Logo
  Use the files as they are. Bone logo on Ink, Ink logo on Paper or white.
  Don't stretch, rotate, recolour or redraw it, and don't add effects.

Questions: hello@merova.app
